package ca.gov.smwa.wcms;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.gitlab4j.api.AbstractApi;
import org.gitlab4j.api.CommitsApi;
import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.ProjectApi;
import org.gitlab4j.api.RepositoryApi;
import org.gitlab4j.api.RepositoryFileApi;
import org.springframework.beans.factory.annotation.Value;
import org.gitlab4j.api.models.Commit;
import org.gitlab4j.api.models.FileUpload;
import org.gitlab4j.api.models.RepositoryFile;
import org.gitlab4j.api.models.TreeItem;

import ca.gov.smwa.wcms.model.User;

public class GitServiceTest {
    private static String gitURL = "https://gccode.ssc-spc.gc.ca";

    public static void main(String[] args) {
		save();
    }
    static String convertStreamToString(java.io.InputStream is) {
        @SuppressWarnings("resource")
		java.util.Scanner s = new java.util.Scanner(is).useDelimiter("\\A");
        return s.hasNext() ? s.next() : "";
    }
   
    
	@SuppressWarnings("deprecation")
	public static void save() {
		GitLabApi gitLabApi = null;
		try {
			gitLabApi = GitLabApi.oauth2Login(gitURL, "frederic.gravel@hrsdc-rhdcc.gc.ca", "fred2000");
//			RepositoryFileA file = gitLabApi.getRepositoryFileApi().getFileInfo(6658, "lb.html", "master");
			CommitsApi commitsApi = new CommitsApi(gitLabApi);  
			
			List<Commit>commits = commitsApi.getCommits(6658,
                    "master",
                    "lb.html");			

			for (Commit commit : commits) {
				System.out.println(commit.getId());
				System.out.println(commit.getCommitterEmail());
				System.out.println(commit.getCreatedAt());
				System.out.println(commit.getId());
				InputStream is = null;
				try {
					is = gitLabApi.getRepositoryFileApi().getRawFile(6658, commit.getId(), "lb.html");//     (6658, "lb.html", "lb.html"));
					System.out.println("fred" + convertStreamToString(is));
				}catch(GitLabApiException e) {
					System.out.println("fred delete ");
				}
			}		
					
			
		} catch (GitLabApiException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}

		
	}
	

}
