package ca.gov.smwa.wcms.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.gitlab4j.api.GitLabApiException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ca.gov.smwa.wcms.model.User;
import ca.gov.smwa.wcms.model.Version;
import ca.gov.smwa.wcms.service.GitService;

@RestController
public class RepoController {
    @Autowired
    private GitService gitService;

//    @RequestMapping(value = "/files/{file_name}", method = RequestMethod.GET)
	@RequestMapping(value = "/api/repo/getVersionFile")
    public void getFile(@RequestParam(value="filename") filename, String versionId, HttpServletResponse response) {
		User user = getCurrentUser();
		try {
          // get your file as InputStream
          InputStream is = gitService.getVersionContent(filename, versionId, user) ;
          // copy it to response's OutputStream
          org.apache.commons.io.IOUtils.copy(is, response.getOutputStream());
          response.flushBuffer();
        } catch (IOException ex) {
          log.info("Error writing file to output stream. Filename was '{}'", fileName, ex);
          throw new RuntimeException("IOError writing file to output stream");
        }
    }
    
    private String getCommitMessage(String action) {
    	Date date = new Date();
    	String modifiedDate= new SimpleDateFormat("yyyy-MM-dd").format(date);
    	User user = getCurrentUser();
    	return modifiedDate + " " + action + " by " + user.getUsername();
    }
	@RequestMapping(value = "/api/repo/deleteFile")
	public String deleteFile(@RequestParam(value="filename") String filename, @RequestParam(value="commitMessage") String commitMessage) {
		String message = "Deleted!";
		User user = getCurrentUser();
		
		try {
			gitService.delete(filename, getCommitMessage("Deleted"), user);
		} catch (GitLabApiException e) {
			e.printStackTrace();
			message = "GitLabApiException=" + e.getMessage();
		}
		return "{\"filename\":\"" + filename + "\", \"response\":\""+ message +"\"}";
	}
    
    @RequestMapping(value = "/api/repo/getVersions")
	public List<Version> getVersions(@RequestParam(value="filename") String filename) {
		User user = getCurrentUser();
		List<Version> list = null;
		try {
			list = gitService.getVersions(filename, user);
		} catch (GitLabApiException e) {
			e.printStackTrace();
		}
		return list;
	}
	
    
    @RequestMapping(value = "/api/repo/saveFile")
	public String saveFile(@RequestParam(value="filename") String filename, @RequestParam(value="commitMessage") String commitMessage) {
		String message = "Saved!";
		User user = getCurrentUser();
		
		try {
			gitService.save(filename, getCommitMessage("Saved"), user);
		} catch (GitLabApiException e) {
			e.printStackTrace();
			message = "GitLabApiException=" + e.getMessage();
		} catch (IOException e) {
			e.printStackTrace();
			message = "IOException=" + e.getMessage();
		}
		return "{\"filename\":\"" + filename + "\", \"response\":\""+ message +"\"}";
	}
	
	private User getCurrentUser(){
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String username = authentication.getName();
		String password = (String) authentication.getCredentials();
		User user = new User(username, password);
		return user;
	}
	
}
