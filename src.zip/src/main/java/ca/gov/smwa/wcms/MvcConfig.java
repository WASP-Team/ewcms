package ca.gov.smwa.wcms;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class MvcConfig implements WebMvcConfigurer{
    @Value("${static.file.location}")
    String staticFileLocation;
    
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/filesys").setViewName("filesys");
        registry.addViewController("/").setViewName("filesys");
        registry.addViewController("/edit").setViewName("edit");
        registry.addViewController("/fileBrowser").setViewName("fileBrowser"); //Michel
        registry.addViewController("/menu").setViewName("menu"); //Michel
    }
    
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry
          .addResourceHandler("/files/**")
          .addResourceLocations("file:///" + staticFileLocation);

     }
}