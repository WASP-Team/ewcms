package ca.gov.smwa.wcms.service;

/* Copyright (c) 2008, 2010, Oracle and/or its affiliates. All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
*
*   - Redistributions of source code must retain the above copyright
*     notice, this list of conditions and the following disclaimer.
*
*   - Redistributions in binary form must reproduce the above copyright
*     notice, this list of conditions and the following disclaimer in the
*     documentation and/or other materials provided with the distribution.
*
*   - Neither the name of Oracle nor the names of its
*     contributors may be used to endorse or promote products derived
*     from this software without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
* IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
* THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
* PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT OWNER OR
* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
* EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
* PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
* PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
* LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
* NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
* SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.XML;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.AccessDeniedException;
import java.nio.file.FileSystems;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import static java.nio.file.StandardWatchEventKinds.ENTRY_CREATE;
import static java.nio.file.StandardWatchEventKinds.ENTRY_DELETE;
import javax.xml.transform.OutputKeys;


/**
 * Example to watch a directory (or tree) for changes to files.
 */

@Service
public class FolderService {
    @Value("${static.file.location}")
    String staticFileLocation;// = "C:/git/gocwcms-repository/docs/edsc-esdc_prv/";

	private WatchService watcher;
	private Map<WatchKey, Path> keys;
	private boolean recursive;
	private boolean trace = false;
	private List<String> fileList = new ArrayList<String>();
	public String test = "";
	private Path dir;
	
	@SuppressWarnings("unchecked")
	static <T> WatchEvent<T> cast(WatchEvent<?> event) {
		return (WatchEvent<T>) event;
	}

	/**
	 * Creates a WatchService and registers the given directory
	 * 
	 * @return
	 */
	public //Constructor.
	FolderService() {}
	
	public void initWatcher(Path dir, boolean recursive){
		this.dir = dir;
		this.recursive = recursive;
	}
	
	public void makeList() throws IOException {
		this.watcher = FileSystems.getDefault().newWatchService();
		this.keys = new HashMap<WatchKey, Path>();
		//this.recursive = recursive;

		System.out.println("staticFileLocation = " + staticFileLocation);
		if (recursive) {
			System.out.format("Scanning %s ...\n", dir);
			registerAll(dir);
			try {
				System.out.println(createXML(dir));
			} catch (Exception e) {
				System.out.println("error " + e.toString());
			}
			XMLToJSON();
		} else {
			//register(dir);
			////// Update xml file here single node.
		}

		// enable trace after initial registration
		this.trace = true;
	}
	
	
	/**
	 * Register the given directory with the WatchService
	 */
	private void register(Path dir) throws IOException {
		WatchKey key = dir.register(watcher, ENTRY_CREATE, ENTRY_DELETE /* , ENTRY_MODIFY */ );
		if (trace) {
			Path prev = keys.get(key);
			if (prev == null) {
				System.out.format("register: %s\n", dir);
			} else {
				if (!dir.equals(prev)) {
					System.out.format("update: %s -> %s\n", prev, dir);
				}
			}
		}
		keys.put(key, dir);
	}

	/**
	 * Register the given directory, and all its sub-directories, with the
	 * WatchService.
	 */
	private void registerAll(final Path start) throws IOException, AccessDeniedException {

		// register directory and sub-directories

		Files.walkFileTree(start, new SimpleFileVisitor<Path>() {

			// ***** This code returns the file's ALSO in the directory tree.
			// ******//
			// @Override
			// public FileVisitResult visitFile(Path file, BasicFileAttributes
			// attrs)
			// throws IOException
			// {
			// System.out.println("All files." + file.toString());
			// register(dir);
			// return FileVisitResult.CONTINUE;
			// }

			@Override
			public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {

				// System.out.println("directory" + " " + dir.toString());
				fileList.add(dir.toString());
				//register(dir);
				return FileVisitResult.CONTINUE;
			}

			@Override
			public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
				if (exc instanceof AccessDeniedException) {
					return FileVisitResult.SKIP_SUBTREE;
				}

				return super.visitFileFailed(file, exc);
			}

		});

	}

	

	/**
	 * Process all events for keys queued to the watcher
	 */
	/*
	void processEvents() {
		for (;;) {

			// wait for key to be signalled
			WatchKey key;
			try {
				key = watcher.take();
			} catch (InterruptedException x) {
				return;
			}

			Path dir = keys.get(key);
			if (dir == null) {
				System.err.println("WatchKey not recognized!!");
				continue;
			}

			for (WatchEvent<?> event : key.pollEvents()) {
				WatchEvent.Kind kind = event.kind();

				// TBD - provide example of how OVERFLOW event is handled
				if (kind == OVERFLOW) {
					continue;
				}

				// Context for directory entry event is the file name of entry
				WatchEvent<Path> ev = cast(event);
				Path name = ev.context();
				Path child = dir.resolve(name);

				// print out event
				System.out.format("%s: %s\n", event.kind().name(), child);

				String nodePath = child.toString().replaceAll(".*\\\\(.*)", "$1");

				if (event.kind().name().equals("ENTRY_DELETE")) {
					delNodeFromXML(event.kind().name(), nodePath);
				}

				if (event.kind().name().equals("ENTRY_CREATE")) {
					addNodeFromXML(event.kind().name(), nodePath);
				}

				// if directory is created, and watching recursively, then
				// register it and its sub-directories
				if (recursive && (kind == ENTRY_CREATE)) {
					try {
						if (Files.isDirectory(child, NOFOLLOW_LINKS)) {
							registerAll(child);
						}
					} catch (IOException x) {
						// ignore to keep sample readbale
					}
				}
			}

			// reset key and remove from set if directory no longer accessible
			boolean valid = key.reset();
			if (!valid) {
				keys.remove(key);

				// all directories are inaccessible
				if (keys.isEmpty()) {
					break;
				}
			}
		}
	}
*/
	private void delNodeFromXML(String nodePath) {

		try {
			String filePath = "//children[@text='negotech']/children[@text='live']/children[@text='" + nodePath + "']";

			System.out.println("will try to Delete : " + filePath);

			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			Document document = dbf.newDocumentBuilder().parse(new File("c:\\apache22\\htdocs\\files.xml"));

			XPath xPath = XPathFactory.newInstance().newXPath();
			Node node = (Node) xPath.compile(filePath).evaluate(document, XPathConstants.NODE);
			System.out.println("aa " + node.getTextContent());
			
			node.getParentNode().removeChild(node);

			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer t = tf.newTransformer();
			t.setOutputProperty(OutputKeys.INDENT, "yes");
			t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			t.transform(new DOMSource(document), new StreamResult(new FileWriter("c:\\apache22\\htdocs\\files.xml")));

			// rewrite json file.
			XMLToJSON();
		} catch (Exception e) {
			System.out.println("Error in process event: " + e.toString());
		}

	}

	public String addNodeFromXML(String nodePath) {
		System.out.println("in addNodeFromXML with = " + nodePath);
			String filePath2 = "";
			String newFile = "";
		try {
			String paths[] = nodePath.split("\\\\");
				
			for (String path : paths)
			{
				if (path == paths[0]) continue;
				filePath2 += "/children[@text='" + path + "']";
				newFile = path; 
			}
			filePath2 = "/" + filePath2.replaceFirst("children", "data");
		//	System.out.println(filePath2);
			String filePath = filePath2.replaceAll("(.*)/.*", "$1");
			System.out.println(filePath);
			//String newFile = filePath2.replaceAll(".*/(.*)", "$1");
			System.out.println(newFile);
		//	filePath = "//data[@text='negotech']/children[@text='live']";
			//filePath2 = "//data[@text='negotech']/children[@text='live']/children[@text='asdf']";
			
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			Document document = dbf.newDocumentBuilder().parse(new File("c:\\apache22\\htdocs\\files.xml"));
			XPath xPath = XPathFactory.newInstance().newXPath();
			Element rootNode = (Element) xPath.compile(filePath).evaluate(document, XPathConstants.NODE);
			
//			Node newNode = document.createElement("children");
			//newNode.setTextContent("asdf");
			
			Element newNode = document.createElement("children");
			newNode.setAttribute("text", newFile );
			newNode.setTextContent(newFile );
			
			//Element newnode = (Element) xPath.compile(filePath2).evaluate(document, XPathConstants.NODE);
	
			/*
			System.out.println("a* " + rootNode.getTextContent());
			System.out.println("b* " + newNode.getTextContent());
			*/
			
			rootNode.appendChild(newNode);
			System.out.println("3");
			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer t = tf.newTransformer();
			t.setOutputProperty(OutputKeys.INDENT, "yes");
			t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
			System.out.println("4");

			t.transform(new DOMSource(document), new StreamResult(new FileWriter("c:\\apache22\\htdocs\\files.xml")));

			// rewrite json file.
			XMLToJSON();

		} catch (Exception e) {
			System.out.println("Error in process ADD event: " + e.toString());
			return "<meta http-equiv=\"refresh\" content=\"0; URL='http://localhost:8080/fileBrowser'\" />";
		}
		return "<meta http-equiv=\"refresh\" content=\"0; URL='http://localhost:8080/fileBrowser'\" />";

	}


/*
	public static void main(String[] args) throws IOException {
		// parse arguments
		if (args.length == 0 || args.length > 2)
			usage();
		boolean recursive = false;
		int dirArg = 0;
		if (args[0].equals("-r")) {
			if (args.length < 2)
				usage();
			recursive = true;
			dirArg++;
		}

		// register directory and process its events
		Path dir = Paths.get(args[dirArg]);
		new WatchDir(dir, recursive).processEvents();
	}
*/
	private static String createXML(Path dir) throws Exception {

		// initiating document factory
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
		Document document = documentBuilder.newDocument();
		Element coreElement = document.createElement("core");
		document.appendChild(coreElement);

		Element rootElement = document.createElement("data");
		coreElement.appendChild(rootElement);

		File path = new File(dir.toString());

		rootElement.setAttribute("text", path.getName());
		// First call to explore the path
		listDirectories(rootElement, document, path);

		// Result output mechanism
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = transformerFactory.newTransformer();
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
		DOMSource source = new DOMSource(document);
		StreamResult result = new StreamResult(new File("C:\\apache22\\htdocs\\files.xml"));
		transformer.transform(source, result);
		System.out.println("file.xml created");
		return "XML file created";
	}

	private static void listDirectories(Element rootElement, Document document, File dir) throws Exception {

		try {

			for (File f : dir.listFiles()) {
				if (f.isDirectory()) { // is it a directory?

					Element childElement = document.createElement("children");
					childElement.setAttribute("text", f.getName());

					// if you want to use the below line then first comment the
					// above line
					childElement.appendChild(document.createTextNode(f.getName()));

					// appending the found dir name to the root element
					rootElement.appendChild(childElement);

					// Recurssive call to the same method where we find any folder in parent folder
					listDirectories(childElement, document, f.getAbsoluteFile());

				} else {
					// NOTE// This is if we want to have the actual files and not folders.
					// what else? it is a file and for a file there is
					// no recursive call obviously ;)
					// Element childElement = document.createElement("File");
					
					// childElement.setAttribute("value", f.getName());
					// if you want to use the below line then first comment the
					// above line
					// childElement.appendChild(document.createTextNode(f.getName()));
					// appending the found dir name to the root element
					// rootElement.appendChild(childElement);
				}
			}

		} catch (AccessDeniedException e) {
			System.out.println("Access denied folder");
		} catch (NullPointerException e) {
			System.out.println("Access denied folder");
		}
	}

	private void XMLToJSON() {

		try {
			int PRETTY_PRINT_INDENT_FACTOR = 4;
			File file = new File("C:\\apache22\\htdocs\\files.xml");

			BufferedReader br = new BufferedReader(new FileReader(file));

			String str;
			String fullXML = "";
			while ((str = br.readLine()) != null) {
				fullXML += str;
			}

			try {
				JSONObject xmlJSONObj = XML.toJSONObject(fullXML);
				String jsonPrettyPrintString = xmlJSONObj.toString(PRETTY_PRINT_INDENT_FACTOR);

				BufferedWriter writer = new BufferedWriter(new FileWriter(staticFileLocation + "files.json"));
				//BufferedWriter writer = new BufferedWriter(new FileWriter("files.json"));
				writer.write(jsonPrettyPrintString);

				writer.close();
				System.out.println("json created at :" + staticFileLocation + "files.json");
			} catch (JSONException je) {
				System.out.println(je.toString());
			}
			br.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
	}
	
	public void refresh(Path dir, boolean recursive) throws IOException{
		this.watcher = FileSystems.getDefault().newWatchService();
		this.keys = new HashMap<WatchKey, Path>();
		this.recursive = recursive;

		if (recursive) {
			System.out.format("Scanning %s ...\n", dir);
			registerAll(dir);
			try {
				System.out.println(createXML(dir));
			} catch (Exception e) {
				System.out.println("error " + e.toString());
			}
			System.out.println("Done.");
			XMLToJSON();
		} else {
			//register(dir);
			////// Update xml file here single node.
		}

		// enable trace after initial registration
		this.trace = true;
	}

}
