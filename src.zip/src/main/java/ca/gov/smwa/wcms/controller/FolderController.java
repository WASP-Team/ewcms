package ca.gov.smwa.wcms.controller;


import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ca.gov.smwa.wcms.service.FolderService2;


	@RestController
	public class FolderController {
		
		@Autowired
		private FolderService2 directoryWatcher;
		
		@Value("${static.file.location}")
	    String staticFileLocation;
		
		@Value("${repository.location}")
		String repositoryLocation;
		
		@Autowired
		@RequestMapping("/folderService")
	    public String makeListing() throws Exception {
			directoryWatcher.scan(repositoryLocation);
			
			return "<meta http-equiv=\"refresh\" content=\"0; URL='http://localhost:8080/menu'\" />";
	    }
	    
/*
	    @RequestMapping(value="/watchDir-add", params={"folderName"})
	    public String addDir(@RequestParam(value="folderName") String folderName) {
	    	System.out.println("Got here with = " + folderName);
	//    	directoryWatcher.addNodeFromXML(folderName);
	  //  	new File(root + folderName).mkdirs();
	    	
			return "<meta http-equiv=\"refresh\" content=\"0; URL='http://localhost:8080/fileBrowser'\" />";
	    }

	    @RequestMapping(value="/watchDir-refresh")
	    public String refreshDir() throws IOException {
	    	System.out.println("refreshing list");
	  //  	directoryWatcher.refresh(path, true);
			return "<meta http-equiv=\"refresh\" content=\"0; URL='http://localhost:8080/fileBrowser'\" />";
	    }
 
	    */
	}
	