package ca.gov.smwa.wcms.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;

import java.nio.file.FileVisitResult;
import static java.nio.file.FileVisitResult.CONTINUE;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


@Service
public class FolderService2 {
    @Value("${repository.location}")
    String repositoryLocation;

    //constructor
    public FolderService2() {
    	System.out.print("FolderService2 loaded");
    }
        
    public static class Finder extends SimpleFileVisitor<Path> {
  
        //Add to xml here.
        void AddToXml(Path file) {  
        	System.out.println(file);
        }
 
        // Invoke the pattern matching method on each directory.
        @Override
        public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
        	AddToXml(dir);
            return CONTINUE;
        }
 
        // Error handling
        @Override
        public FileVisitResult visitFileFailed(Path file, IOException exc) {
            System.err.println(exc);
            return CONTINUE;
        }
    }
 
     public void scan(String path) throws IOException {
 
        Path startingDir = Paths.get(path);
 
        Finder finder = new Finder();
        Files.walkFileTree(startingDir, finder);
       
    }
    
}