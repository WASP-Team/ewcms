package ca.gov.smwa.wcms.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class ExampleService{
    @Value("${static.file.location}")
    String staticFileLocation;
	Logger logger = LoggerFactory.getLogger(ExampleService.class);
	
	public ExampleService() {
		
	}
	
	public void debug() {
		logger.debug("From ExampleService staticFileLocation=" + staticFileLocation);		
	}
}
