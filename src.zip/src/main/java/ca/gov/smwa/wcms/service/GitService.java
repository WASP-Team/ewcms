package ca.gov.smwa.wcms.service;


import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.gitlab4j.api.CommitsApi;
import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.RepositoryFileApi;
import org.gitlab4j.api.models.Commit;
import org.gitlab4j.api.models.RepositoryFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import ca.gov.smwa.wcms.model.User;
import ca.gov.smwa.wcms.model.Version;

@Service
public class GitService {
    @Value("${git.url}")
    private String gitURL;
    @Value("${repository.location}")
    private String repositoryLocation;
    @Value("${git.projectID}")
    private int projectID;

    

	Logger logger = LoggerFactory.getLogger(GitService.class);
    
	@SuppressWarnings("deprecation")
	private GitLabApi getGitLabApi(User user) throws GitLabApiException {
		return GitLabApi.oauth2Login(gitURL, user.getUsername(), user.getPassword());
	}
	
	public InputStream getVersionContent(String filename, String commitId, User user) throws GitLabApiException {
		InputStream is = null;
		is = getGitLabApi(user).getRepositoryFileApi().getRawFile(projectID, commitId, filename);
		return is;
	}
	
	public List<Version> getVersions(String filename, User user) throws GitLabApiException{
		CommitsApi commitsApi = getGitLabApi(user).getCommitsApi(); 
		List<Commit>commits = commitsApi.getCommits(projectID, "master", filename);
		List<Version> versions = new ArrayList<Version>();
		for (Commit commit : commits) {
			Version version = new Version();
			version.setCommittedDate(commit.getCommittedDate()); 
			version.setCommitterEmail(commit.getCommitterEmail());
			version.setId(commit.getId()); 
			version.setMessage(commit.getMessage()); 
			versions.add(version);
		}
		return versions;
	}

	
	public void delete(String filename, String commitMessage, User user) throws GitLabApiException{
		GitLabApi gitLabApi = getGitLabApi(user);
		RepositoryFileApi repositoryFileApi = new RepositoryFileApi(gitLabApi);
		repositoryFileApi.deleteFile(filename, projectID, "master", commitMessage);
	}
	
	public void save(String filename, String commitMessage, User user) throws GitLabApiException, IOException {
		GitLabApi gitLabApi = getGitLabApi(user);
		RepositoryFileApi repositoryFileApi = new RepositoryFileApi(gitLabApi);
		RepositoryFile file = new  RepositoryFile();

		Path path = Paths.get(repositoryLocation + filename);
		byte[] contentByte = Files.readAllBytes(path);

		file.setFileName(filename);
		file.setFilePath(filename);
		file.encodeAndSetContent(contentByte);

		try {
			file = repositoryFileApi.updateFile(file, projectID, "master", commitMessage);
		} catch (GitLabApiException e1) {
			if (e1.getMessage().equals("A file with this name doesn't exist")) {
				try {
					file = repositoryFileApi.createFile(file, projectID, "master", commitMessage);
				} catch (GitLabApiException e2) {
					// TODO Auto-generated catch block
					e2.printStackTrace();
				}
			}else {
				e1.printStackTrace();
			}
		}
		
	}
}
