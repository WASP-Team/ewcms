package ca.gov.smwa.wcms.model;

import java.util.Date;

public class Version{
	private Date committedDate; 
	private String committerEmail; 
	private String id; 
	private String message; 

	public Date getCommittedDate() {
		return committedDate;
	}
	public void setCommittedDate(Date committedDate) {
		this.committedDate = committedDate;
	}
	public String getCommitterEmail() {
		return committerEmail;
	}
	public void setCommitterEmail(String committerEmail) {
		this.committerEmail = committerEmail;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
}
