package ca.gov.smwa.wcms;

import java.util.ArrayList;
import java.util.List;
import org.gitlab4j.api.GitLabApi;
import org.gitlab4j.api.GitLabApiException;
import org.gitlab4j.api.models.ProjectUser;
import org.gitlab4j.api.models.User;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

public class GitAuthenticationProvider implements AuthenticationProvider {
	private String url;// = "https://gccode.ssc-spc.gc.ca";		
	private int projectID;// = 6658; // https://gccode.ssc-spc.gc.ca/Teamsite-devops/gocwcms-repository.git-6628
	
	public GitAuthenticationProvider(String url, int projectID) {
		this.url = url;
		this.projectID = projectID;
	}
	
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		String name = authentication.getName();
		Object credentials = authentication.getCredentials();
		System.out.println("credentials class: " + credentials.getClass());
		if (!(credentials instanceof String)) {
			return null; 
		}
		String password = credentials.toString();

		if (!gitAuthentication(name, password)) {
			throw new BadCredentialsException("Authentication failed for " + name);
		}
		

		
		
		List<GrantedAuthority> grantedAuthorities = new ArrayList<>();
		grantedAuthorities.add(new SimpleGrantedAuthority("ROLE_USER"));
		Authentication auth = new UsernamePasswordAuthenticationToken(name, password, grantedAuthorities);
		return auth;
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return authentication.equals(UsernamePasswordAuthenticationToken.class);
	}
	

	private boolean gitAuthentication(String loginUser, CharSequence password) {
		boolean response = false;
		String username = "";

		try {
			GitLabApi gitLabApi = GitLabApi.oauth2Login(url, loginUser, password);
			List<User> users = gitLabApi.getUserApi().findUsers(loginUser);
			for (User user : users) {
				username = user.getUsername();
			}
			List<ProjectUser> projectusers = null;
			projectusers = gitLabApi.getProjectApi().getProjectUsers(projectID);
			for (ProjectUser projectuser : projectusers) {
				if (username.equals(projectuser.getUsername())) {
					response = true;
					break;
				}
			}
		} catch (GitLabApiException e) {
			// TODO Auto-generated catch block
			// e.printStackTrace();
			response = false;
		}
		return response;
	}

}