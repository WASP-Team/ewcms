package ca.gov.smwa.wcms.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import ca.gov.smwa.wcms.service.ExampleService;

@Controller
public class ExampleController {
    @Autowired
    private ExampleService exampleService;

    @Value("${static.file.location}")
    String staticFileLocation;
	Logger logger = LoggerFactory.getLogger(ExampleController.class);
	
    @RequestMapping(method=RequestMethod.GET, value="/example")
    public String handleRequest(){
    	logger.debug("From Example Controller staticFileLocation=" + staticFileLocation);
    	exampleService.debug();
    	return "example";
    }
	
}
